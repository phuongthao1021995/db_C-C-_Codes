// I2C device class (I2Cdev) demonstration Arduino sketch for MPU6050 class, 3D math helper
// 6/5/2012 by Jeff Rowberg <jeff@rowberg.net>
// Updates should (hopefully) always be available at https://github.com/jrowberg/i2cdevlib
//
// Changelog:
//     2012-06-05 - add 3D math helper file to DMP6 example sketch

/* ============================================
I2Cdev device library code is placed under the MIT license
Copyright (c) 2012 Jeff Rowberg

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
===============================================
*/


#ifndef	__MPU6050_3DMATHLIB_H_
#define __MPU6050_3DMATHLIB_H_

#include	<math.h>
#include 	<stdint.h>

typedef struct __quaternion__ {

	float w = 1.0f;
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;

} Quaternion;

/* Functions for Quaternion: */

Quaternion	Quaternion_Init(void) {
	Quaternion tmp_Qu;
	
	tmp_Qu.w = 1.0f;
    tmp_Qu.x = 0.0f;
	tmp_Qu.y = 0.0f;
	tmp_Qu.z = 0.0f;
	
	return	tmp_Qu;
}

Quaternion	Quaternion_setValues(float iW, float iX, float iY, float iZ) {
	Quaternion tmp_Qu;
	
	tmp_Qu.w = iW;
	tmp_Qu.x = iX;
	tmp_Qu.y = iY;
	tmp_Qu.z = iZ;
	
	return	tmp_Qu;
}

float		Quaternion_getMagnitude(Quaternion iQu) {
	return	(float)sqrt((double)(iQu.w*iQu.w) + (double)(iQu.x*iQu.x) + (double)(iQu.y*iQu.y) + (double)(iQu.z*iQu.z));
}

Quaternion	Quaternion_getProduct(Quaternion iQu_1, Quaternion iQu_2) {
	/* Quaternion multiplication is defined by: */
	//     (Q1 * Q2).w = (w1w2 - x1x2 - y1y2 - z1z2)
	//     (Q1 * Q2).x = (w1x2 + x1w2 + y1z2 - z1y2)
	//     (Q1 * Q2).y = (w1y2 - x1z2 + y1w2 + z1x2)
	//     (Q1 * Q2).z = (w1z2 + x1y2 - y1x2 + z1w2
		
	Quaternion tmp_ProductQu;
	tmp_ProductQu.w = iQu_1.w*iQu_2.w - iQu_1.x*iQu_2.x - iQu_1.y*iQu_2.y - iQu_1.z*iQu_2.z;
	tmp_ProductQu.x = iQu_1.w*iQu_2.x - iQu_1.x*iQu_2.w - iQu_1.y*iQu_2.z - iQu_1.z*iQu_2.y;
	tmp_ProductQu.y = iQu_1.w*iQu_2.y - iQu_1.x*iQu_2.z - iQu_1.y*iQu_2.w - iQu_1.z*iQu_2.x;
	tmp_ProductQu.z = iQu_1.w*iQu_2.z - iQu_1.x*iQu_2.y - iQu_1.y*iQu_2.x - iQu_1.z*iQu_2.w;
	
	return tmp_ProductQu;
}

Quaternion	Quaternion_getConjugate(Quaternion iQu) {
	iQu.w = iQu.w;
	iQu.x = -iQu.x;
	iQu.y = -iQu.y;
	iQu.z = -iQu.z;
	
	return iQu;
}

Quaternion 	Quaternion_getNormalize(Quaternion iQu) {
	float iQu_m = Quaternion_getMagnitude(iQu);
	iQu.w /= iQu_m;
	iQu.x /= iQu_m;
	iQu.y /= iQu_m;
	iQu.z /= iQu_m;
	
	return	iQu;
}

/* End of Quaternion Functions */

typedef	struct __vector_int16__ {
	int16_t x = 0;
	int16_t y = 0;
	int16_t z = 0;
} Vector_Int16;

/* Functions for Vector_Int16 */

Vector_Int16	VectorInt16_Init(void) {
	Vector_Int16	tmp_Vector;
	
	tmp_Vector.x = 0;
	tmp_Vector.y = 0;
	tmp_Vector.z = 0;
	
	return	tmp_Vector;
}
        
Vector_Int16	VectorInt16_setValues(int16_t nx, int16_t ny, int16_t nz) {
	Vector_Int16	tmp_Vector;
	
	tmp_Vector.x = nx;
	tmp_Vector.y = ny;
	tmp_Vector.z = nz;
	
	return	tmp_Vector;
}

float 			VectorInt16_getMagnitude(Vector_Int16	iVector) {
	return	(float)sqrt((double)(iVector.x*iVector.x) + (double)(iVector.y*iVector.y) + (double)(iVector.z*iVector.z));
}
        
Vector_Int16	VectorInt16_getNormalized(Vector_Int16	iVector) {
	float	iVector_m = VectorInt16_getMagnitude(iVector);
	iVector.x /= m;
	iVector.y /= m;
	iVector.z /= m;
	
	return	iVector;
}
        
Vector_Int16	VectorInt16_getRotate(Vector_Int16	iVector, Quaternion q) {
	// http://www.cprogramming.com/tutorial/3d/quaternions.html
	// http://www.euclideanspace.com/maths/algebra/realNormedAlgebra/quaternions/transforms/index.htm
	// http://content.gpwiki.org/index.php/OpenGL:Tutorials:Using_Quaternions_to_represent_rotation
	// ^ or: http://webcache.googleusercontent.com/search?q=cache:xgJAp3bDNhQJ:content.gpwiki.org/index.php/OpenGL:Tutorials:Using_Quaternions_to_represent_rotation&hl=en&gl=us&strip=1

	// P_out = q * P_in * conj(q)
	// - P_out is the output vector
	// - q is the orientation quaternion
	// - P_in is the input vector (a*aReal)
	// - conj(q) is the conjugate of the orientation quaternion (q=[w,x,y,z], q*=[w,-x,-y,-z])
	Quaternion p = Quaternion_setValues(0, iVector.x, iVector.y, iVector.z);

	// quaternion multiplication: q * p, stored back in p
	p = Quaternion_getProduct(q,p);

	// quaternion multiplication: p * conj(q), stored back in p
	p = Quaternion_getProduct(p, Quaternion_getConjugate(q));

	// p quaternion is now [0, x', y', z']
	iVector.x = p.x;
	iVector.y = p.y;
	iVector.z = p.z;
	
	return	iVector;
}

/* End of Vector_Int16 functions */


typedef	struct	__vector_float__ {
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;
} Vector_Float;

/* Functions for Vector_Float */

Vector_Float	VectorFloat_Init(void) {
	Vector_Float	tmp_VectorF;
	
	tmp_VectorF.x = 0.0f;
	tmp_VectorF.y = 0.0f;
	tmp_VectorF.z = 0.0f;
	
	return	tmp_VectorF;
}
        
Vector_Float	VectorFloat_setValues(float nx, float ny, float nz) {
	Vector_Float	tmp_VectorF;
	
	tmp_VectorF.x = nx;
	tmp_VectorF.y = ny;
	tmp_VectorF.z = nz;
	
	return	tmp_VectorF;
}

float 			VectorFloat_getMagnitude(Vector_Float	iVectorF) {
	return	(float)sqrt((double)(iVectorF.x*iVectorF.x) + (double)(iVectorF.y*iVectorF.y) + (double)(iVectorF.z*iVectorF.z));
}
        
Vector_Float 	VectorFloat_getNormalized(Vector_Float	iVectorF) {
	float	iVectorF_m = VectorFloat_getMagnitude(iVectorF);
	
	iVectorF.x /= iVectorF_m;
	iVectorF.y /= iVectorF_m;
	iVectorF.z /= iVectorF_m;
	
	return	iVectorF;
}
        
Vector_Float	VectorFloat_getRotate(Vector_Float	iVectorF, Quaternion q) {
	Quaternion p = Quaternion_setValues(0, iVectorF.x, iVectorF.y, iVectorF.z);

	// quaternion multiplication: q * p, stored back in p
	p = Quaternion_getProduct(q, p);

	// quaternion multiplication: p * conj(q), stored back in p
	p = Quaternion_getProduct(p, Quaternion_getConjugate(q));

	// p quaternion is now [0, x', y', z']
	iVectorF.x = p.x;
	iVectorF.y = p.y;
	iVectorF.z = p.z;
	
	return	iVectorF;
}


/* End of Vector_Float functions */

#endif